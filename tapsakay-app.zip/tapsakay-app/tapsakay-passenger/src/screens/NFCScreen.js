import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
export default function NFCScreen(){ return (<View style={styles.container}><Text style={styles.text}>NFC / Scan placeholder</Text></View>); }
const styles = StyleSheet.create({ container:{flex:1,backgroundColor:'#0A4E99',justifyContent:'center',alignItems:'center'}, text:{color:'#fff'} });
